package com.example.sorteadorapp

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnSortear = findViewById<Button>(R.id.btn_sortear)
        val sorteado = findViewById<TextView>(R.id.tv_sorteado)

        val numero = IntArray(7) // Definindo o tamanho do array como 7

        btnSortear.setOnClickListener {
            var aleatorio: Int
            var sorteioTexto = ""

            for (i in 0 until 7) {
                do {
                    aleatorio = sortear()
                } while (numero.contains(aleatorio))

                numero[i] = aleatorio

                // Acumulando o texto para exibir todos os sorteios ao final
                sorteioTexto += "${i + 1}º: ${numero[i]}\n"
            }

            sorteado.text = sorteioTexto
        }
    }

    fun sortear(): Int {
        // Sorteia um número aleatório entre 0 e 100
        return Random.nextInt(61)
    }
}
